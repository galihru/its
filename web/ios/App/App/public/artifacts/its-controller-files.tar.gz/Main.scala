import java.nio.charset.StandardCharsets
import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.net.URLEncoder
import java.nio.file.Files
import java.nio.file.Paths
import java.nio.file.StandardOpenOption
import java.io.ByteArrayOutputStream
import java.time.Instant
import java.time.Duration
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.TimeUnit
import java.util.Base64
import java.util.Locale

object ItsController {
  private case class GeoLocation(
    lat: Double,
    lng: Double,
    source: String,
    label: String,
    accuracyM: Int
  )

  private case class BrowserYoloPayload(
    summary: YoloFrameSummary,
    thumbnailUrl: String,
    trafficLevel: String,
    cameraDatasetJson: String
  )

  private val offlineAfterMs      = math.max(60_000, envInt("ITS_OFFLINE_AFTER_MS", 60_000))
  private val staleDeleteAfterMs  = math.max(offlineAfterMs, envInt("ITS_STALE_DELETE_AFTER_MS", 60_000).toLong)
  private val deviceId            = env("ITS_DEVICE_ID",    "raspberry-its")
  private val label               = env("ITS_DEVICE_LABEL", "Raspberry Pi 5 Controller")
  private val status              = env("ITS_STATUS",       "online")
  private val note                = env("ITS_NOTE",         "controller aktif")

  private val fallbackLatitude   = envDouble("ITS_FALLBACK_LATITUDE",  0.0)
  private val fallbackLongitude  = envDouble("ITS_FALLBACK_LONGITUDE", 0.0)
  private val explicitLatitude   = envDoubleOpt("ITS_LATITUDE")
  private val explicitLongitude  = envDoubleOpt("ITS_LONGITUDE")
  private val locationMode       = env("ITS_LOCATION_MODE", "auto").toLowerCase(Locale.ROOT)
  private val gpsEnabled         = env("ITS_GPS_ENABLED", "true").toLowerCase(Locale.ROOT) != "false"
  private val gpsDevice          = env("ITS_GPS_DEVICE", "/dev/serial0")
  private val gpsBaudRate        = math.max(1_200, envInt("ITS_GPS_BAUD", 9_600))
  private val gpsRetryMs         = math.max(1_000L, envInt("ITS_GPS_RETRY_MS", 5_000).toLong)
  private val gpsWatchStarted    = new AtomicBoolean(false)

  private val intervalSeconds     = math.max(1, envInt("ITS_INTERVAL_SECONDS", 15))
  private val geoRefreshMs        = math.max(5_000L, envInt("ITS_GEO_REFRESH_SECONDS", intervalSeconds).toLong * 1000L)
  private val outputPath          = env("ITS_OUTPUT_PATH", "../web/public/data/its-state.json")
  private val ipGeolocationUrls   = env(
    "ITS_IP_GEOLOCATION_URLS",
    "https://ipapi.co/json/,https://ipwho.is/"
  ).split(",").map(_.trim).filter(_.nonEmpty).toSeq
  private val firebaseUrl         = env(
    "ITS_FIREBASE_BASE_URL",
    "https://itstelkom-default-rtdb.asia-southeast1.firebasedatabase.app/devices"
  )
  private val firebaseRootUrl     = firebaseUrl.trim.stripSuffix("/").stripSuffix("/devices")
  private val firebaseAuth    = env("ITS_FIREBASE_AUTH", "")
  private var firebaseEnabled = env("ITS_FIREBASE_ENABLED", "true").toLowerCase(Locale.ROOT) != "false"
  private val browserYoloEnabled = env("ITS_BROWSER_YOLO_ENABLED", "true").toLowerCase(Locale.ROOT) != "false"
  private val browserYoloStaleMs = math.max(3_000L, envInt("ITS_BROWSER_YOLO_STALE_MS", 15_000).toLong)
  private val cameraDatasetEnabled = env("ITS_CAMERA_DATASET_ENABLED", "true").toLowerCase(Locale.ROOT) != "false"
  private val cameraDatasetMs = math.max(5_000L, envInt("ITS_CAMERA_DATASET_MS", 10_000).toLong)
  private val cameraDatasetUrl = env("ITS_CAMERA_DATASET_URL", "")
  private val publishOfflineOnShutdown = env("ITS_PUBLISH_OFFLINE_ON_SHUTDOWN", "false").toLowerCase(Locale.ROOT) == "true"
  private var cachedLocation: Option[(Long, GeoLocation)] = None
  @volatile private var cachedGpsLocation: Option[(Long, GeoLocation)] = None

  private val cameraEnabled    = env("ITS_CAMERA_ENABLED", "true").toLowerCase(Locale.ROOT) != "false"
  private val webrtcEnabled    = env("ITS_WEBRTC_ENABLED", "true").toLowerCase(Locale.ROOT) != "false"
  private val cameraMode       = {
    val requested = env("ITS_CAMERA_MODE", "webrtc").toLowerCase(Locale.ROOT)
    if (requested == "webrtc" || requested == "mjpeg") requested else "webrtc"
  }
  private val webrtcSignalPath = env("ITS_WEBRTC_SIGNAL_PATH", s"webrtc/devices/$deviceId").stripPrefix("/").stripSuffix("/")
  private val cameraPublicUrl  = resolveCameraPublicUrl()
  private val cameraHlsPublicUrl = resolveCameraHlsPublicUrl(cameraPublicUrl)

  @volatile private var cameraStatus: String = if (cameraEnabled && (cameraPublicUrl.nonEmpty || webrtcEnabled)) "online" else "disabled"
  @volatile private var cameraUpdatedAt: Long = 0L
  @volatile private var cameraError: String = ""

  private val yoloConfig = YoloConfig.fromEnv(defaultCameraSource = resolveYoloCameraFallback())
  private val yoloDetector = YoloDetector.create(yoloConfig)
  @volatile private var latestEffectiveVehicleCount = 0
  @volatile private var latestEffectiveTrafficLevel = "lancar"
  @volatile private var latestCameraThumbnailUrl = ""
  @volatile private var latestCameraDatasetJson = "{}"
  @volatile private var latestCameraDatasetAt = 0L
  private val trafficSignal = TrafficSignalController.fromEnv(() => latestEffectiveVehicleCount)

  private val httpClient = HttpClient.newHttpClient()
  private val lastSeenFormatter = DateTimeFormatter
    .ofPattern("EEEE, dd MMMM yyyy HH:mm:ss")
    .withLocale(new Locale("id", "ID"))
    .withZone(ZoneId.systemDefault())

  def main(args: Array[String]): Unit = {
    initCameraState()
    startGpsWatcher()
    yoloDetector.start()
    trafficSignal.start()

    val startupLocation = currentLocation()
    println(s"ITS controller started — device=$deviceId lat=${startupLocation.lat} lng=${startupLocation.lng} source=${startupLocation.source} -> $outputPath")
    println(s"Camera mode=$cameraMode enabled=$cameraEnabled webrtc=$webrtcEnabled publicUrl=${if (cameraPublicUrl.nonEmpty) cameraPublicUrl else "(firebase-signaling)"}")
    println(s"YOLO enabled=${yoloConfig.enabled} model=${yoloConfig.modelPath} source=${yoloConfig.cameraSource}")
    Runtime.getRuntime.addShutdownHook(new Thread(() => {
      trafficSignal.stop()
      yoloDetector.close()
      if (publishOfflineOnShutdown) publishOfflineDevice()
    }))
    // Saat startup: cek dan hapus node lama yang masih berisi nested snapshot wrapper
    migrateLegacyFirebaseNode()
    if (args.contains("--once")) {
      Thread.sleep(math.min(1200L, yoloConfig.sampleEveryMs))
      writeSnapshot()
      trafficSignal.stop()
      yoloDetector.close()
      return
    }
    while (true) {
      writeSnapshot()
      Thread.sleep(intervalSeconds * 1000L)
    }
  }

  /**
   * Deteksi node lama di Firebase: devices/{deviceId} yang masih berisi
   * {"devices":[...],"source":...,"updatedAt":...} dan hapus sebelum
   * menulis struktur baru yang flat.
   * Dipanggil sekali saat startup.
   */
  private def migrateLegacyFirebaseNode(): Unit = {
    if (!firebaseEnabled || firebaseUrl.trim.isEmpty) return
    val nodePath = s"${firebaseUrl.stripSuffix("/")}/${deviceId}.json${authSuffixQuery()}"
    try {
      val getReq = HttpRequest.newBuilder(URI.create(nodePath))
        .header("Accept", "application/json").GET().build()
      val getResp = httpClient.send(getReq, HttpResponse.BodyHandlers.ofString())
      if (getResp.statusCode() < 200 || getResp.statusCode() >= 300) return
      val body = getResp.body().trim
      // Jika node lama mengandung "devices" key (nested), hapus dulu
      if (body.contains("\"devices\"")) {
        println(s"[${java.time.LocalDateTime.now()}] Detected legacy Firebase structure for $deviceId — deleting to migrate...")
        val delReq = HttpRequest.newBuilder(URI.create(nodePath)).DELETE().build()
        val delResp = httpClient.send(delReq, HttpResponse.BodyHandlers.ofString())
        if (delResp.statusCode() >= 200 && delResp.statusCode() < 300) {
          println(s"[${java.time.LocalDateTime.now()}] Legacy node deleted. Will write flat structure on next snapshot.")
        } else {
          println(s"[${java.time.LocalDateTime.now()}] Legacy delete failed: HTTP ${delResp.statusCode()}")
        }
      } else {
        println(s"[${java.time.LocalDateTime.now()}] Firebase node structure OK — no migration needed.")
      }
    } catch {
      case ex: Exception =>
        println(s"[${java.time.LocalDateTime.now()}] Migration check error: ${ex.getMessage}")
    }
  }

  private def writeSnapshot(): Unit = {
    publishCameraDatasetIfDue()
    val (snapshotJson, deviceJson) = buildJsonPair()

    // Tulis file lokal (format snapshot penuh untuk web)
    val path = Paths.get(outputPath)
    val parent = path.getParent
    if (parent != null) Files.createDirectories(parent)

    Files.writeString(
      path, snapshotJson, StandardCharsets.UTF_8,
      StandardOpenOption.CREATE,
      StandardOpenOption.TRUNCATE_EXISTING,
      StandardOpenOption.WRITE
    )
    println(s"[${java.time.LocalDateTime.now()}] wrote ${path.toAbsolutePath}")

    // FIX: kirim hanya deviceJson (bukan snapshotJson) ke Firebase
    // agar struktur RTDB: devices/{deviceId} = {id, label, status, lastSeen, position, ...}
    publishFirebaseDevice(deviceJson)
    cleanupStaleNonRaspberryNodes()
  }

  /**
   * Mengembalikan dua string JSON:
   *   1. snapshotJson — format penuh untuk file lokal & web frontend
   *   2. deviceJson   — hanya data device, untuk disimpan di Firebase RTDB
   *
   * FIX: Sebelumnya hanya ada satu JSON (snapshotJson) yang dikirim ke Firebase,
   * sehingga node Firebase berisi {"updatedAt":...,"source":...,"devices":[...]}
   * alih-alih {id, label, status, lastSeen, position, ...}.
   * Frontend membaca Firebase dan mengharapkan struktur device langsung.
   */
  private def buildJsonPair(): (String, String) = {
    val lastSeen    = System.currentTimeMillis()
    val updatedAt   = lastSeen
    val lastSeenText = lastSeenFormatter.format(Instant.ofEpochMilli(lastSeen))
    val location = currentLocation()
    val detector = effectiveDetector(yoloDetector.snapshot())
    latestEffectiveVehicleCount = detector.vehicleCount
    latestEffectiveTrafficLevel = trafficLevelFor(detector.vehicleCount)
    val signal = trafficSignal.snapshot()

    // Device JSON — struktur flat yang sesuai dengan SnapshotDevice di frontend
    val deviceJson =
      s"""{
         |  "id": "${escapeJson(deviceId)}",
         |  "label": "${escapeJson(label)}",
         |  "status": "${escapeJson(status)}",
         |  "lastSeen": $lastSeen,
         |  "lastSeenText": "${escapeJson(lastSeenText)}",
         |  "note": "${escapeJson(note)}",
         |  "roadName": "${escapeJson(location.label)}",
         |  "locationSource": "${escapeJson(location.source)}",
         |  "locationLabel": "${escapeJson(location.label)}",
         |  "locationAccuracyM": ${location.accuracyM},
         |  "cameraEnabled": ${cameraEnabled},
         |  "cameraMode": "${escapeJson(cameraMode)}",
         |  "webrtcEnabled": ${cameraEnabled && webrtcEnabled},
         |  "webrtcPath": "${escapeJson(webrtcSignalPath)}",
         |  "webrtcUrl": "${escapeJson(if (cameraEnabled) cameraPublicUrl else "")}",
         |  "cameraReady": ${cameraEnabled && ((cameraMode == "webrtc" && webrtcEnabled) || cameraPublicUrl.nonEmpty)},
         |  "cameraUrl": "${escapeJson(if (cameraEnabled) cameraPublicUrl else "")}",
         |  "cameraHlsUrl": "${escapeJson(if (cameraEnabled) cameraHlsPublicUrl else "")}",
         |  "cameraStatus": "${escapeJson(cameraStatus)}",
         |  "cameraUpdatedAt": ${cameraUpdatedAt},
         |  "cameraNote": "${escapeJson(cameraError)}",
         |  "cameraThumbnailUrl": "${escapeJson(latestCameraThumbnailUrl)}",
         |  "cameraDataset": $latestCameraDatasetJson,
         |  "detectorStatus": "${escapeJson(detector.status)}",
         |  "detectorNote": "${escapeJson(detector.note)}",
         |  "detectorUpdatedAt": ${detector.updatedAt},
         |  "detectorFps": ${formatDouble(detector.fps)},
         |  "detectorFrameWidth": ${detector.frameWidth},
         |  "detectorFrameHeight": ${detector.frameHeight},
         |  "objectCount": ${detector.objectCount},
         |  "detectorCameraSource": "${escapeJson(if (detector.status.startsWith("browser-yolo")) cameraPublicUrl else yoloConfig.cameraSource)}",
         |  "detectorConfidence": ${formatDouble(yoloConfig.confidenceThreshold)},
         |  "detectorOutputShape": "${escapeJson(detector.outputShape)}",
         |  "vehicleCount": ${detector.vehicleCount},
         |  "vehicleBreakdown": ${vehicleBreakdownJson(detector.vehicleBreakdown)},
         |  "detections": ${detectionsJson(detector.detections)},
         |  "trafficLevel": "${escapeJson(latestEffectiveTrafficLevel)}",
         |  "trafficColor": "${escapeJson(signal.color)}",
         |  "trafficStartedAt": ${signal.startedAt},
         |  "trafficDurationSec": ${signal.durationSec},
         |  "trafficSource": "${escapeJson(signal.source)}",
         |  "gpioBackend": "${escapeJson(signal.gpioBackend)}",
         |  "gpioReady": ${signal.gpioReady},
         |  "gpioNote": "${escapeJson(signal.gpioNote)}",
         |  "position": {
         |    "lat": ${location.lat},
         |    "lng": ${location.lng}
         |  }
         |}""".stripMargin

    // Snapshot JSON — wrapper untuk file lokal (web frontend membaca ini)
    val snapshotJson =
      s"""{
         |  "updatedAt": $updatedAt,
         |  "source": "scala-controller",
         |  "devices": [
         |    $deviceJson
         |  ]
         |}""".stripMargin

    (snapshotJson, deviceJson)
  }

  private def effectiveDetector(local: YoloFrameSummary): YoloFrameSummary = {
    fetchBrowserYoloPayload() match {
      case Some(payload) =>
        if (payload.thumbnailUrl.nonEmpty) latestCameraThumbnailUrl = payload.thumbnailUrl
        if (payload.cameraDatasetJson.nonEmpty) latestCameraDatasetJson = payload.cameraDatasetJson
        latestEffectiveTrafficLevel = payload.trafficLevel
        payload.summary
      case None =>
        local
    }
  }

  private def fetchBrowserYoloPayload(): Option[BrowserYoloPayload] = {
    if (!browserYoloEnabled || !firebaseEnabled || firebaseRootUrl.isEmpty) return None
    val nodePath = s"${firebaseRootUrl}/browserYolo/devices/${deviceId}.json${authSuffixQuery()}"

    try {
      val request = HttpRequest
        .newBuilder(URI.create(nodePath))
        .timeout(Duration.ofSeconds(2))
        .header("Accept", "application/json")
        .GET()
        .build()
      val response = httpClient.send(request, HttpResponse.BodyHandlers.ofString())
      if (response.statusCode() < 200 || response.statusCode() >= 300) return None
      val body = Option(response.body()).getOrElse("").trim
      if (body.isEmpty || body == "null") return None

      val updatedAt = extractNumber(body, "updatedAt").map(_.toLong).getOrElse(0L)
      if (updatedAt <= 0 || System.currentTimeMillis() - updatedAt > browserYoloStaleMs) return None

      val breakdown = extractVehicleBreakdown(body)
      val detections = extractYoloDetections(body)
      val vehicleCount = extractNumber(body, "vehicleCount").map(v => math.max(0, math.round(v).toInt)).getOrElse(breakdown.total)
      val objectCount = extractNumber(body, "objectCount").map(v => math.max(0, math.round(v).toInt)).getOrElse(detections.size)
      val trafficLevel = extractString(body, "trafficLevel")
        .filter(level => level == "lancar" || level == "sedang" || level == "padat")
        .getOrElse(trafficLevelFor(vehicleCount))
      val frameWidth = extractNumber(body, "frameWidth").map(v => math.max(0, math.round(v).toInt)).getOrElse(0)
      val frameHeight = extractNumber(body, "frameHeight").map(v => math.max(0, math.round(v).toInt)).getOrElse(0)
      val fps = extractNumber(body, "fps").getOrElse(0.0)
      val thumbnailUrl = extractString(body, "thumbnailUrl").getOrElse("")
      val cameraDatasetJson = extractJsonBlock(body, "cameraDataset", '{', '}')
        .filter(_.trim.nonEmpty)
        .getOrElse("{}")

      Some(BrowserYoloPayload(
        summary = YoloFrameSummary(
          status = "browser-yolo",
          note = extractString(body, "note").getOrElse("YOLO browser aktif"),
          updatedAt = updatedAt,
          fps = fps,
          frameWidth = frameWidth,
          frameHeight = frameHeight,
          objectCount = objectCount,
          outputShape = extractString(body, "modelUrl").getOrElse("browser-yolo"),
          vehicleCount = vehicleCount,
          vehicleBreakdown = breakdown,
          detections = detections
        ),
        thumbnailUrl = thumbnailUrl,
        trafficLevel = trafficLevel,
        cameraDatasetJson = cameraDatasetJson
      ))
    } catch {
      case ex: Exception =>
        println(s"[${java.time.LocalDateTime.now()}] Browser YOLO fetch error: ${ex.getMessage}")
        None
    }
  }

  private def publishCameraDatasetIfDue(): Unit = {
    val now = System.currentTimeMillis()
    if (!cameraDatasetEnabled || !firebaseEnabled || firebaseRootUrl.isEmpty) return
    if (!cameraEnabled || cameraPublicUrl.trim.isEmpty || cameraStatus != "online") return
    if (now - latestCameraDatasetAt < cameraDatasetMs) return
    latestCameraDatasetAt = now

    val captured = cameraDatasetCandidateUrls().view
      .flatMap { url =>
        captureCameraJpeg(url).map { firstBytes =>
          try Thread.sleep(650L)
          catch { case _: InterruptedException => Thread.currentThread().interrupt() }
          val secondBytes = captureCameraJpeg(url).getOrElse(firstBytes)
          (url, firstBytes, secondBytes)
        }
      }
      .headOption

    captured match {
      case Some((sourceUrl, bytes1, bytes2)) if bytes1.nonEmpty && bytes2.nonEmpty =>
        val detector = effectiveDetector(yoloDetector.snapshot())
        val location = currentLocation()
        val signal = trafficSignal.snapshot()
        val dataUrl1 = "data:image/jpeg;base64," + Base64.getEncoder.encodeToString(bytes1)
        val dataUrl2 = "data:image/jpeg;base64," + Base64.getEncoder.encodeToString(bytes2)
        val datasetPath = s"trafficObjectDetectionDataset/devices/$deviceId"
        val datasetJson =
          s"""{
             |  "updatedAt": $now,
             |  "source": "raspberry-camera",
             |  "deviceId": "${escapeJson(deviceId)}",
             |  "cameraUrl": "${escapeJson(sourceUrl)}",
             |  "format": "image/jpeg",
             |  "intervalMs": $cameraDatasetMs,
             |  "nama1": "${escapeJson(dataUrl1)}",
             |  "nama2": "${escapeJson(dataUrl2)}",
             |  "snapshot1Url": "${escapeJson(dataUrl1)}",
             |  "snapshot2Url": "${escapeJson(dataUrl2)}",
             |  "detectorStatus": "${escapeJson(detector.status)}",
             |  "detectorFrameWidth": ${detector.frameWidth},
             |  "detectorFrameHeight": ${detector.frameHeight},
             |  "vehicleCount": ${detector.vehicleCount},
             |  "vehicleBreakdown": ${vehicleBreakdownJson(detector.vehicleBreakdown)},
             |  "detections": ${detectionsJson(detector.detections)},
             |  "trafficColor": "${escapeJson(signal.color)}",
             |  "trafficDurationSec": ${signal.durationSec},
             |  "locationLabel": "${escapeJson(location.label)}",
             |  "position": {
             |    "lat": ${location.lat},
             |    "lng": ${location.lng}
             |  }
             |}""".stripMargin
        latestCameraDatasetJson =
          s"""{
             |  "snapshot1Url": "${escapeJson(dataUrl1)}",
             |  "snapshot2Url": "${escapeJson(dataUrl2)}",
             |  "updatedAt": $now,
             |  "source": "raspberry-camera",
             |  "path": "${escapeJson(datasetPath)}"
             |}""".stripMargin
        if (latestCameraThumbnailUrl.isEmpty) latestCameraThumbnailUrl = dataUrl1
        putFirebaseJson(datasetPath, datasetJson, "camera dataset")
      case _ =>
        println(s"[${java.time.LocalDateTime.now()}] Camera dataset skipped: no JPEG frame from candidates ${cameraDatasetCandidateUrls().mkString(", ")}")
    }
  }

  private def cameraDatasetCandidateUrls(): Seq[String] = {
    val public = cameraPublicUrl.trim
    Seq(
      Option(cameraDatasetUrl.trim).filter(_.nonEmpty),
      Option(public).filter(_.nonEmpty),
      Option(cameraHlsPublicUrl.trim).filter(_.nonEmpty),
      Some("http://127.0.0.1:8888/cam/index.m3u8"),
      Some("http://127.0.0.1:8888/cam/")
    ).flatten.distinct
  }

  private def captureCameraJpeg(url: String): Option[Array[Byte]] = {
    if (url.toLowerCase(Locale.ROOT).contains(".m3u8")) {
      return captureHlsJpegWithFfmpeg(url)
    }
    captureMjpegJpeg(url).orElse {
      if (url.endsWith("/")) captureHlsJpegWithFfmpeg(url.stripSuffix("/") + "/index.m3u8")
      else None
    }
  }

  private def captureMjpegJpeg(url: String): Option[Array[Byte]] = {
    var input: java.io.InputStream = null
    try {
      val conn = URI.create(url).toURL.openConnection()
      conn.setConnectTimeout(3000)
      conn.setReadTimeout(6000)
      conn.setRequestProperty("User-Agent", "ITS-controller-camera-dataset/1.0")
      input = conn.getInputStream
      val out = new ByteArrayOutputStream()
      var started = false
      var prev = -1
      var current = input.read()
      val maxBytes = 1_200_000
      while (current >= 0 && out.size() < maxBytes) {
        if (!started) {
          if (prev == 0xff && current == 0xd8) {
            started = true
            out.write(0xff)
            out.write(0xd8)
          }
        } else {
          out.write(current)
          if (prev == 0xff && current == 0xd9) return Some(out.toByteArray)
        }
        prev = current
        current = input.read()
      }
      None
    } catch {
      case ex: Exception =>
        println(s"[${java.time.LocalDateTime.now()}] Camera dataset capture error: ${ex.getMessage}")
        None
    } finally {
      if (input != null) {
        try input.close()
        catch { case _: Exception => () }
      }
    }
  }

  private def captureHlsJpegWithFfmpeg(url: String): Option[Array[Byte]] = {
    try {
      val process = new ProcessBuilder(
        "ffmpeg",
        "-loglevel", "error",
        "-nostdin",
        "-i", url,
        "-frames:v", "1",
        "-f", "image2pipe",
        "-vcodec", "mjpeg",
        "pipe:1"
      )
        .redirectError(ProcessBuilder.Redirect.DISCARD)
        .start()
      val out = new ByteArrayOutputStream()
      val buffer = new Array[Byte](8192)
      var done = false
      while (!done) {
        val read = process.getInputStream.read(buffer)
        if (read < 0) done = true
        else out.write(buffer, 0, read)
      }
      val finished = process.waitFor(8, TimeUnit.SECONDS)
      if (!finished) {
        process.destroyForcibly()
        return None
      }
      val bytes = out.toByteArray
      if (bytes.length > 4 && (bytes(0) & 0xff) == 0xff && (bytes(1) & 0xff) == 0xd8) Some(bytes)
      else None
    } catch {
      case ex: Exception =>
        println(s"[${java.time.LocalDateTime.now()}] HLS camera dataset capture error: ${ex.getMessage}")
        None
    }
  }

  private def putFirebaseJson(path: String, json: String, label: String): Unit = {
    val nodePath = s"${firebaseRootUrl}/${path.stripPrefix("/")}.json${authSuffixQuery()}"
    try {
      val request = HttpRequest
        .newBuilder(URI.create(nodePath))
        .timeout(Duration.ofSeconds(4))
        .header("Content-Type", "application/json")
        .PUT(HttpRequest.BodyPublishers.ofString(json))
        .build()
      val response = httpClient.send(request, HttpResponse.BodyHandlers.ofString())
      if (response.statusCode() >= 200 && response.statusCode() < 300) {
        println(s"[${java.time.LocalDateTime.now()}] published $label to Firebase RTDB: $path")
      } else {
        println(s"[${java.time.LocalDateTime.now()}] Firebase $label publish failed: HTTP ${response.statusCode()} — ${response.body().take(160)}")
      }
    } catch {
      case ex: Exception =>
        println(s"[${java.time.LocalDateTime.now()}] Firebase $label publish error: ${ex.getMessage}")
    }
  }

  private def trafficLevelFor(count: Int): String = {
    val safe = math.max(0, count)
    val lancarMax = math.max(0, envInt("ITS_TRAFFIC_LANCAR_MAX", 5))
    val sedangMax = math.max(lancarMax + 1, envInt("ITS_TRAFFIC_SEDANG_MAX", 10))
    if (safe <= lancarMax) "lancar"
    else if (safe <= sedangMax) "sedang"
    else "padat"
  }

  // ─── Firebase: publish device node ────────────────────────────

  /**
   * FIX: fungsi ini menggantikan publishFirebaseSnapshot.
   * Hanya mengirim deviceJson (bukan snapshotJson) ke path devices/{deviceId}.
   * Dengan demikian struktur RTDB menjadi benar dan frontend bisa parse
   * devices sebagai Record<string, SnapshotDevice>.
   */
  private def publishFirebaseDevice(deviceJson: String): Unit = {
    if (!firebaseEnabled || firebaseUrl.trim.isEmpty) return

    val devicePath = s"${firebaseUrl.stripSuffix("/")}/${deviceId}.json" +
      authSuffix()

    try {
      val request = HttpRequest
        .newBuilder(URI.create(devicePath))
        .header("Content-Type", "application/json")
        .method("PATCH", HttpRequest.BodyPublishers.ofString(deviceJson))
        .build()

      val response = httpClient.send(request, HttpResponse.BodyHandlers.ofString())
      if (response.statusCode() >= 200 && response.statusCode() < 300) {
        val location = currentLocation()
        println(s"[${java.time.LocalDateTime.now()}] published device to Firebase RTDB: $deviceId @ (${location.lat}, ${location.lng}) from ${location.source}")
      } else {
        println(s"[${java.time.LocalDateTime.now()}] Firebase publish failed: HTTP ${response.statusCode()} — ${response.body().take(200)}")
        if (response.statusCode() == 401) {
          firebaseEnabled = false
          println(s"[${java.time.LocalDateTime.now()}] Firebase disabled: unauthorized. Set ITS_FIREBASE_AUTH atau periksa rules database.")
        }
      }
    } catch {
      case ex: Exception =>
        println(s"[${java.time.LocalDateTime.now()}] Firebase publish error: ${ex.getMessage}")
    }
  }

  // ─── Firebase: cleanup stale nodes ────────────────────────────

  private def cleanupStaleNonRaspberryNodes(): Unit = {
    if (!firebaseEnabled || firebaseUrl.trim.isEmpty) return

    try {
      val request = HttpRequest
        .newBuilder(URI.create(s"${firebaseUrl.stripSuffix("/")}.json${authSuffixQuery()}"))
        .header("Accept", "application/json")
        .GET()
        .build()

      val response = httpClient.send(request, HttpResponse.BodyHandlers.ofString())
      if (response.statusCode() < 200 || response.statusCode() >= 300) {
        println(s"[${java.time.LocalDateTime.now()}] Firebase cleanup skipped: HTTP ${response.statusCode()}")
        return
      }

      val staleIds = extractStaleDeviceIds(response.body(), staleDeleteAfterMs)
        .filterNot(_.startsWith("raspberry"))
        .filterNot(_ == deviceId)

      staleIds.foreach(deleteDeviceNode)
    } catch {
      case ex: Exception =>
        println(s"[${java.time.LocalDateTime.now()}] Firebase cleanup error: ${ex.getMessage}")
    }
  }

  private def deleteDeviceNode(id: String): Unit = {
    val deleteUrl = s"${firebaseUrl.stripSuffix("/")}/${id}.json${authSuffixQuery()}"
    try {
      val request = HttpRequest
        .newBuilder(URI.create(deleteUrl))
        .DELETE()
        .build()
      val response = httpClient.send(request, HttpResponse.BodyHandlers.ofString())
      if (response.statusCode() >= 200 && response.statusCode() < 300)
        println(s"[${java.time.LocalDateTime.now()}] deleted stale node $id from Firebase RTDB")
      else
        println(s"[${java.time.LocalDateTime.now()}] Firebase delete failed for $id: HTTP ${response.statusCode()}")
    } catch {
      case ex: Exception =>
        println(s"[${java.time.LocalDateTime.now()}] Firebase delete error for $id: ${ex.getMessage}")
    }
  }

  private def extractStaleDeviceIds(json: String, staleAfterMs: Long): Seq[String] = {
    val entryPattern = """(?s)"([^\"]+)"\s*:\s*\{.*?"lastSeen"\s*:\s*(\d+)""".r
    val cutoff = System.currentTimeMillis() - staleAfterMs
    entryPattern.findAllMatchIn(json).flatMap { m =>
      val id       = m.group(1)
      val lastSeen = try m.group(2).toLong catch { case _: Throwable => 0L }
      if (lastSeen > 0 && lastSeen < cutoff) Some(id) else None
    }.toSeq
  }

  // ─── Helpers ──────────────────────────────────────────────────

  /** Mengembalikan "?auth=..." atau "" */
  private def authSuffix(): String =
    if (firebaseAuth.trim.isEmpty) ""
    else s"?auth=${URLEncoder.encode(firebaseAuth.trim, StandardCharsets.UTF_8)}"

  /** Sama dengan authSuffix tapi untuk URL yang sudah diakhiri .json */
  private def authSuffixQuery(): String = authSuffix()

  private def initCameraState(): Unit = {
    if (!cameraEnabled) {
      cameraStatus = "disabled"
      cameraUpdatedAt = 0L
      cameraError = "camera disabled by ITS_CAMERA_ENABLED=false"
      println(s"[${java.time.LocalDateTime.now()}] ${cameraError}")
      return
    }

    if (cameraPublicUrl.trim.nonEmpty) {
      cameraStatus = "online"
      cameraUpdatedAt = System.currentTimeMillis()
      cameraError = ""
      println(s"[${java.time.LocalDateTime.now()}] Public camera URL active: $cameraPublicUrl")
      return
    }

    if (cameraMode == "webrtc" && webrtcEnabled) {
      cameraStatus = "online"
      cameraUpdatedAt = System.currentTimeMillis()
      cameraError = "Firebase WebRTC signaling active; no private LAN camera URL is published"
      println(s"[${java.time.LocalDateTime.now()}] ${cameraError}")
      return
    }

    cameraStatus = "error"
    cameraUpdatedAt = 0L
    cameraError = "Set ITS_CAMERA_PUBLIC_URL / ITS_CAMERA_WEBRTC_URL, atau aktifkan ITS_CAMERA_MODE=webrtc"
    println(s"[${java.time.LocalDateTime.now()}] ${cameraError}")
  }

  private def publishOfflineDevice(): Unit = {
    if (!firebaseEnabled || firebaseUrl.trim.isEmpty) return
    val lastSeen = System.currentTimeMillis()
    val lastSeenText = lastSeenFormatter.format(Instant.ofEpochMilli(lastSeen))
    val location = currentLocation()
    val detector = yoloDetector.snapshot()
    val signal = trafficSignal.snapshot()
    val body =
      s"""{
         |  "id": "${escapeJson(deviceId)}",
         |  "label": "${escapeJson(label)}",
         |  "status": "offline",
         |  "lastSeen": $lastSeen,
         |  "lastSeenText": "${escapeJson(lastSeenText)}",
         |  "note": "${escapeJson(note)}; controller berhenti",
         |  "roadName": "${escapeJson(location.label)}",
         |  "locationSource": "${escapeJson(location.source)}",
         |  "locationLabel": "${escapeJson(location.label)}",
         |  "locationAccuracyM": ${location.accuracyM},
         |  "cameraEnabled": ${cameraEnabled},
         |  "cameraMode": "${escapeJson(cameraMode)}",
         |  "webrtcEnabled": ${cameraEnabled && webrtcEnabled},
         |  "webrtcPath": "${escapeJson(webrtcSignalPath)}",
         |  "webrtcUrl": "${escapeJson(if (cameraEnabled) cameraPublicUrl else "")}",
         |  "cameraReady": false,
         |  "cameraUrl": "${escapeJson(if (cameraEnabled) cameraPublicUrl else "")}",
         |  "cameraHlsUrl": "${escapeJson(if (cameraEnabled) cameraHlsPublicUrl else "")}",
         |  "detectorStatus": "${escapeJson(detector.status)}",
         |  "detectorNote": "controller offline",
         |  "detectorUpdatedAt": ${detector.updatedAt},
         |  "detectorFps": 0,
         |  "detectorFrameWidth": ${detector.frameWidth},
         |  "detectorFrameHeight": ${detector.frameHeight},
         |  "objectCount": 0,
         |  "detectorCameraSource": "${escapeJson(yoloConfig.cameraSource)}",
         |  "detectorConfidence": ${formatDouble(yoloConfig.confidenceThreshold)},
         |  "detectorOutputShape": "${escapeJson(detector.outputShape)}",
         |  "vehicleCount": ${detector.vehicleCount},
         |  "vehicleBreakdown": ${vehicleBreakdownJson(detector.vehicleBreakdown)},
         |  "detections": [],
         |  "trafficColor": "${escapeJson(signal.color)}",
         |  "trafficStartedAt": ${signal.startedAt},
         |  "trafficDurationSec": ${signal.durationSec},
         |  "trafficSource": "${escapeJson(signal.source)}",
         |  "gpioBackend": "${escapeJson(signal.gpioBackend)}",
         |  "gpioReady": ${signal.gpioReady},
         |  "gpioNote": "${escapeJson(signal.gpioNote)}",
         |  "position": {
         |    "lat": ${location.lat},
         |    "lng": ${location.lng}
         |  }
         |}""".stripMargin
    try publishFirebaseDevice(body)
    catch { case _: Throwable => () }
  }

  private def currentLocation(): GeoLocation = {
    val baseLocation = (locationMode match {
      case "manual" =>
        manualLocation()
          .orElse(gpsLocation())
          .orElse(firebaseLocation())
          .orElse(ipGeolocation())
      case "gps" =>
        gpsLocation()
          .orElse(manualLocation())
          .orElse(firebaseLocation())
          .orElse(ipGeolocation())
      case "firebase" =>
        firebaseLocation()
          .orElse(gpsLocation())
          .orElse(manualLocation())
          .orElse(ipGeolocation())
      case "ip" =>
        ipGeolocation()
          .orElse(gpsLocation())
          .orElse(manualLocation())
          .orElse(firebaseLocation())
      case _ =>
        gpsLocation()
          .orElse(manualLocation())
          .orElse(firebaseLocation())
          .orElse(ipGeolocation())
    }).getOrElse(GeoLocation(
      fallbackLatitude,
      fallbackLongitude,
      "fallback",
      "fallback coordinate",
      50_000
    ))

    if (baseLocation.source == "gps-nmea") baseLocation
    else snapToRoad(baseLocation).getOrElse(baseLocation)
  }

  private def gpsLocation(): Option[GeoLocation] = {
    if (!gpsEnabled) return None
    cachedGpsLocation.map(_._2)
  }

  private def startGpsWatcher(): Unit = {
    if (!gpsEnabled || !gpsWatchStarted.compareAndSet(false, true)) return

    val watcher = new Thread(() => watchGpsDevice(), "its-gps-watcher")
    watcher.setDaemon(true)
    watcher.start()
  }

  private def watchGpsDevice(): Unit = {
    println(s"[${java.time.LocalDateTime.now()}] GPS watcher started for $gpsDevice @ $gpsBaudRate baud")
    while (true) {
      try {
        if (!Files.exists(Paths.get(gpsDevice))) {
          println(s"[${java.time.LocalDateTime.now()}] GPS device not found: $gpsDevice")
          Thread.sleep(gpsRetryMs)
        } else {
          val reader = Files.newBufferedReader(Paths.get(gpsDevice), StandardCharsets.US_ASCII)
          try {
            var line = reader.readLine()
            while (line != null) {
              parseGpsSentence(line).foreach { location =>
                cachedGpsLocation = Some(System.currentTimeMillis() -> location)
              }
              line = reader.readLine()
            }
          } finally {
            reader.close()
          }
        }
      } catch {
        case ex: Exception =>
          println(s"[${java.time.LocalDateTime.now()}] GPS watcher error: ${ex.getMessage}")
          Thread.sleep(gpsRetryMs)
      }
    }
  }

  private def parseGpsSentence(sentence: String): Option[GeoLocation] = {
    val cleaned = sentence.trim
    if (!cleaned.startsWith("$") || cleaned.length < 10) return None

    val body = cleaned.takeWhile(_ != '*')
    val fields = body.split(",", -1).map(_.trim)
    if (fields.isEmpty) return None

    fields.headOption match {
      case Some(head) if head.endsWith("GGA") =>
        for {
          fixQuality <- fields.lift(6).flatMap(parseInt)
          if fixQuality > 0
          latitude <- nmeaCoordinate(fields.lift(2).getOrElse(""), fields.lift(3).getOrElse(""))
          longitude <- nmeaCoordinate(fields.lift(4).getOrElse(""), fields.lift(5).getOrElse(""))
          if latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180
        } yield {
          val satellites = fields.lift(7).flatMap(parseInt).getOrElse(0)
          val hdop = fields.lift(8).flatMap(parseDouble).getOrElse(10.0)
          GeoLocation(
            latitude,
            longitude,
            "gps-nmea",
            if (satellites > 0) s"GPS fix ($satellites sat)" else "GPS fix",
            math.max(5, math.round(hdop * 5.0).toInt)
          )
        }
      case Some(head) if head.endsWith("RMC") =>
        fields.lift(2) match {
          case Some("A") =>
            for {
              latitude <- nmeaCoordinate(fields.lift(3).getOrElse(""), fields.lift(4).getOrElse(""))
              longitude <- nmeaCoordinate(fields.lift(5).getOrElse(""), fields.lift(6).getOrElse(""))
              if latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180
            } yield GeoLocation(latitude, longitude, "gps-nmea", "GPS fix", 10)
          case _ => None
        }
      case _ => None
    }
  }

  private def nmeaCoordinate(value: String, hemisphere: String): Option[Double] = {
    val raw = value.trim
    val hemi = hemisphere.trim.toUpperCase(Locale.ROOT)
    if (raw.isEmpty || hemi.isEmpty) return None

    parseDouble(raw).map { numeric =>
      val degrees = (numeric / 100).toInt
      val minutes = numeric - (degrees * 100)
      val decimal = degrees + (minutes / 60.0)
      if (hemi == "S" || hemi == "W") -decimal else decimal
    }
  }

  private def parseInt(value: String): Option[Int] =
    try Some(value.trim.toInt)
    catch { case _: NumberFormatException => None }

  private def manualLocation(): Option[GeoLocation] = {
    if (locationMode != "manual") return None
    for {
      lat <- explicitLatitude
      lng <- explicitLongitude
      if lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180
    } yield GeoLocation(lat, lng, "env", "ITS_LATITUDE/ITS_LONGITUDE", 0)
  }

  private def ipGeolocation(): Option[GeoLocation] = {
    val now = System.currentTimeMillis()
    cachedLocation match {
      case Some((updatedAt, location)) if now - updatedAt < geoRefreshMs =>
        return Some(location)
      case _ => ()
    }

    val fresh = ipGeolocationUrls.view.flatMap(fetchIpGeolocation).headOption
    fresh.foreach(location => cachedLocation = Some(now -> location))
    fresh
  }

  private def fetchIpGeolocation(url: String): Option[GeoLocation] = {
    try {
      val request = HttpRequest
        .newBuilder(URI.create(url))
        .header("Accept", "application/json")
        .header("User-Agent", "its-maps-controller/1.0")
        .GET()
        .build()
      val response = httpClient.send(request, HttpResponse.BodyHandlers.ofString())
      if (response.statusCode() < 200 || response.statusCode() >= 300) return None
      parseIpGeolocation(response.body(), url)
    } catch {
      case ex: Exception =>
        println(s"[${java.time.LocalDateTime.now()}] IP geolocation failed from $url: ${ex.getMessage}")
        None
    }
  }

  private def parseIpGeolocation(json: String, url: String): Option[GeoLocation] = {
    val lat =
      extractNumber(json, "latitude")
        .orElse(extractNumber(json, "lat"))
    val lng =
      extractNumber(json, "longitude")
        .orElse(extractNumber(json, "lon"))
        .orElse(extractNumber(json, "lng"))

    for {
      latitude <- lat
      longitude <- lng
      if latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180
    } yield {
      val city = extractString(json, "city").getOrElse("")
      val region = extractString(json, "region")
        .orElse(extractString(json, "regionName"))
        .getOrElse("")
      val country = extractString(json, "country_name")
        .orElse(extractString(json, "country"))
        .getOrElse("")
      val ip = extractString(json, "ip")
        .orElse(extractString(json, "query"))
        .getOrElse("")
      val label = Seq(city, region, country).filter(_.nonEmpty).mkString(", ")
      val accuracy = extractNumber(json, "accuracy_radius").map(_.toInt).getOrElse(50_000)
      GeoLocation(
        latitude,
        longitude,
        "ip-geolocation",
        if (label.nonEmpty) s"$label${if (ip.nonEmpty) s" / $ip" else ""}" else url,
        accuracy
      )
    }
  }

  private def firebaseLocation(): Option[GeoLocation] = {
    if (!firebaseEnabled || firebaseUrl.trim.isEmpty) return None
    val nodePath = s"${firebaseUrl.stripSuffix("/")}/${deviceId}.json${authSuffixQuery()}"
    try {
      val request = HttpRequest
        .newBuilder(URI.create(nodePath))
        .header("Accept", "application/json")
        .GET()
        .build()
      val response = httpClient.send(request, HttpResponse.BodyHandlers.ofString())
      if (response.statusCode() < 200 || response.statusCode() >= 300) return None
      extractPosition(response.body())
    } catch {
      case _: Exception => None
    }
  }

  private def extractPosition(json: String): Option[GeoLocation] = {
    for {
      lat <- extractNumber(json, "lat")
      lng <- extractNumber(json, "lng")
      if lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180
    } yield GeoLocation(lat, lng, "firebase-cache", "last Firebase position", 50_000)
  }

  private def snapToRoad(location: GeoLocation): Option[GeoLocation] = {
    if (location.lat == 0.0 && location.lng == 0.0) return Some(location)

    val nearestUrl = s"https://router.project-osrm.org/nearest/v1/driving/${location.lng},${location.lat}?number=1"
    try {
      val request = HttpRequest
        .newBuilder(URI.create(nearestUrl))
        .header("Accept", "application/json")
        .header("User-Agent", "its-maps-controller/1.0")
        .GET()
        .build()
      val response = httpClient.send(request, HttpResponse.BodyHandlers.ofString())
      if (response.statusCode() < 200 || response.statusCode() >= 300) return Some(location)

      val body = response.body()
      extractOsrmWaypoint(body)
        .map { case (snappedLng, snappedLat, osrmName) =>
          val roadName = reverseRoadName(snappedLat, snappedLng)
            .orElse(Some(osrmName).filter(_.nonEmpty))
            .orElse(Some(location.label))
            .getOrElse(location.label)
          GeoLocation(
            snappedLat,
            snappedLng,
            "road-snapped",
            roadName,
            math.min(location.accuracyM, 50)
          )
        }
        .orElse(Some(location))
    } catch {
      case _: Exception => Some(location)
    }
  }

  private def extractOsrmWaypoint(json: String): Option[(Double, Double, String)] = {
    val locationPattern = """(?s)"location"\s*:\s*\[\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\]""".r
    val namePattern = """(?s)"name"\s*:\s*"([^"]*)""".r
    for {
      locationMatch <- locationPattern.findFirstMatchIn(json)
    } yield {
      val lng = locationMatch.group(1).toDouble
      val lat = locationMatch.group(2).toDouble
      val name = namePattern.findFirstMatchIn(json).map(m => unescapeJsonString(m.group(1))).getOrElse("")
      (lng, lat, name)
    }
  }

  private def reverseRoadName(lat: Double, lng: Double): Option[String] = {
    val reverseUrl = s"https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=$lat&lon=$lng&zoom=18&addressdetails=1"
    try {
      val request = HttpRequest
        .newBuilder(URI.create(reverseUrl))
        .header("Accept", "application/json")
        .header("User-Agent", "its-maps-controller/1.0")
        .GET()
        .build()
      val response = httpClient.send(request, HttpResponse.BodyHandlers.ofString())
      if (response.statusCode() < 200 || response.statusCode() >= 300) return None

      val body = response.body()
      extractString(body, "road")
        .orElse(extractString(body, "pedestrian"))
        .orElse(extractString(body, "service"))
        .orElse(extractString(body, "residential"))
        .orElse(extractString(body, "footway"))
        .orElse(extractString(body, "path"))
        .orElse(extractString(body, "display_name").flatMap(_.split(",").headOption.map(_.trim)))
    } catch {
      case _: Exception => None
    }
  }

  private def env(name: String, fallback: String): String = {
    val value = System.getenv(name)
    if (value == null || value.trim.isEmpty) fallback else value.trim
  }

  private def envInt(name: String, fallback: Int): Int =
    try env(name, fallback.toString).toInt
    catch { case _: NumberFormatException => fallback }

  private def envDouble(name: String, fallback: Double): Double =
    try env(name, fallback.toString).toDouble
    catch { case _: NumberFormatException => fallback }

  private def envDoubleOpt(name: String): Option[Double] = {
    val value = System.getenv(name)
    if (value == null || value.trim.isEmpty) None else parseDouble(value.trim)
  }

  private def extractNumber(json: String, key: String): Option[Double] = {
    val pattern = (""""""" + java.util.regex.Pattern.quote(key) + """"\s*:\s*(-?\d+(?:\.\d+)?)""").r
    pattern.findFirstMatchIn(json).flatMap(m => parseDouble(m.group(1)))
  }

  private def extractString(json: String, key: String): Option[String] = {
    val pattern = (""""""" + java.util.regex.Pattern.quote(key) + """"\s*:\s*"([^"]*)"""").r
    pattern.findFirstMatchIn(json).map(m => unescapeJsonString(m.group(1))).filter(_.nonEmpty)
  }

  private def extractJsonBlock(json: String, key: String, open: Char, close: Char): Option[String] = {
    val keyToken = "\"" + key + "\""
    val keyIndex = json.indexOf(keyToken)
    if (keyIndex < 0) return None
    val start = json.indexOf(open, keyIndex + keyToken.length)
    if (start < 0) return None

    var depth = 0
    var inString = false
    var escaped = false
    var i = start
    while (i < json.length) {
      val ch = json.charAt(i)
      if (inString) {
        if (escaped) escaped = false
        else if (ch == '\\') escaped = true
        else if (ch == '"') inString = false
      } else {
        if (ch == '"') inString = true
        else if (ch == open) depth += 1
        else if (ch == close) {
          depth -= 1
          if (depth == 0) return Some(json.substring(start, i + 1))
        }
      }
      i += 1
    }
    None
  }

  private def extractVehicleBreakdown(json: String): VehicleBreakdown = {
    val block = extractJsonBlock(json, "vehicleBreakdown", '{', '}').getOrElse("")
    val car = extractNumber(block, "car").map(v => math.max(0, math.round(v).toInt)).getOrElse(0)
    val motorcycle = extractNumber(block, "motorcycle").map(v => math.max(0, math.round(v).toInt)).getOrElse(0)
    val bus = extractNumber(block, "bus").map(v => math.max(0, math.round(v).toInt)).getOrElse(0)
    val truck = extractNumber(block, "truck").map(v => math.max(0, math.round(v).toInt)).getOrElse(0)
    val bicycle = extractNumber(block, "bicycle").map(v => math.max(0, math.round(v).toInt)).getOrElse(0)
    VehicleBreakdown(car = car, motorcycle = motorcycle, bus = bus, truck = truck, bicycle = bicycle)
  }

  private def extractYoloDetections(json: String): Seq[YoloDetection] = {
    val array = extractJsonBlock(json, "detections", '[', ']').getOrElse("")
    val objectPattern = """(?s)\{([^{}]*)\}""".r
    objectPattern.findAllMatchIn(array).flatMap { m =>
      val block = m.group(1)
      for {
        label <- extractString(block, "label")
        confidence <- extractNumber(block, "confidence")
        x <- extractNumber(block, "x")
        y <- extractNumber(block, "y")
        width <- extractNumber(block, "width")
        height <- extractNumber(block, "height")
        if width > 0 && height > 0
      } yield YoloDetection(label, confidence, x, y, width, height)
    }.toSeq.take(80)
  }

  private def parseDouble(value: String): Option[Double] =
    try Some(value.toDouble)
    catch { case _: NumberFormatException => None }

  private def unescapeJsonString(value: String): String =
    value
      .replace("\\\"", "\"")
      .replace("\\/", "/")
      .replace("\\n", "\n")
      .replace("\\r", "\r")
      .replace("\\t", "\t")

  private def escapeJson(value: String): String =
    Option(value).getOrElse("")
      .replace("\\", "\\\\")
      .replace("\"", "\\\"")
      .replace("\n", "\\n")
      .replace("\r", "\\r")
      .replace("\t", "\\t")

  private def vehicleBreakdownJson(value: VehicleBreakdown): String =
    s"""{"car":${value.car},"motorcycle":${value.motorcycle},"bus":${value.bus},"truck":${value.truck},"bicycle":${value.bicycle},"total":${value.total}}"""

  private def detectionsJson(values: Seq[YoloDetection]): String =
    values.map { detection =>
      val isVehicle = yoloConfig.vehicleClassNames.contains(detection.label.toLowerCase(Locale.ROOT))
      s"""{"label":"${escapeJson(detection.label)}","confidence":${formatDouble(detection.confidence)},"vehicle":${isVehicle},"x":${formatDouble(detection.x)},"y":${formatDouble(detection.y)},"width":${formatDouble(detection.width)},"height":${formatDouble(detection.height)}}"""
    }.mkString("[", ",", "]")

  private def formatDouble(value: Double): String =
    if (value.isNaN || value.isInfinity) "0"
    else java.lang.String.format(Locale.US, "%.4f", Double.box(value))

  private def resolveCameraPublicUrl(): String =
    Seq("ITS_CAMERA_PUBLIC_URL", "ITS_CAMERA_WEBRTC_URL", "ITS_CAMERA_URL")
      .map(name => env(name, ""))
      .find(_.nonEmpty)
      .getOrElse("")

  private def resolveCameraHlsPublicUrl(publicUrl: String): String =
    Seq("ITS_CAMERA_HLS_URL", "ITS_CAMERA_PUBLIC_HLS_URL")
      .map(name => env(name, ""))
      .find(_.nonEmpty)
      .getOrElse {
        val trimmed = publicUrl.trim
        if (trimmed.nonEmpty && !trimmed.toLowerCase(Locale.ROOT).contains(".m3u8")) trimmed.stripSuffix("/") + "/index.m3u8"
        else trimmed
      }

  private def resolveYoloCameraFallback(): String =
    Seq(
      env("ITS_YOLO_CAMERA_SOURCE", ""),
      env("ITS_CAMERA_SOURCE", ""),
      env("ITS_CAMERA_DEVICE", "")
    ).find(_.nonEmpty).getOrElse("/dev/video0")
}

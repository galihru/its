#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUNDLE_FILE="${1:-$SCRIPT_DIR/its-controller-files.tar.gz}"
CHECKSUM_FILE="${2:-$BUNDLE_FILE.sha256}"

mkdir -p "$(dirname "$BUNDLE_FILE")"

tar \
  --exclude='./.git' \
  --exclude='./.bsp' \
  --exclude='./.scala-build' \
  --exclude='./.controller-update.*' \
  --exclude='./.venv-webrtc' \
  --exclude='./node_modules' \
  --exclude='./out' \
  --exclude='./__pycache__' \
  --exclude='./*.class' \
  --exclude='./*.tasty' \
  --exclude='./*.log' \
  --exclude='./.camera-tunnel.pid' \
  --exclude='./.its-controller-files.tar.gz.*' \
  --exclude='./scala-cli-aarch64-pc-linux' \
  --exclude='./ItsController.jar.bak' \
  --exclude='./its-controller-files.tar.gz' \
  --exclude='./its-controller-files.tar.gz.sha256' \
  --exclude='./ItsController.jar.previous' \
  -czf "$BUNDLE_FILE" \
  -C "$SCRIPT_DIR" .

sha256sum "$BUNDLE_FILE" | awk '{print $1}' > "$CHECKSUM_FILE"

echo "Built controller bundle: $BUNDLE_FILE"
echo "Checksum: $(cat "$CHECKSUM_FILE")"

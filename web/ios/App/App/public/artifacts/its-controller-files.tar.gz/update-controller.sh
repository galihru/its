#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="${ITS_CONTROLLER_TARGET_DIR:-$SCRIPT_DIR}"
JAR_FILE="$TARGET_DIR/ItsController.jar"
BACKUP_FILE="$TARGET_DIR/ItsController.jar.previous"
LOCAL_BUNDLE_FILE="$TARGET_DIR/its-controller-files.tar.gz"
LOCAL_BUNDLE_SHA_FILE="$TARGET_DIR/its-controller-files.tar.gz.sha256"
TMP_BUNDLE_FILE="$(mktemp "$TARGET_DIR/.its-controller-files.tar.gz.XXXXXX")"
TMP_SHA_FILE="$(mktemp "$TARGET_DIR/.its-controller-files.tar.gz.sha256.XXXXXX")"
STAGING_DIR="$(mktemp -d "$TARGET_DIR/.controller-update.XXXXXX")"
LOCK_FILE="$SCRIPT_DIR/.update-controller.lock"
DOWNLOAD_URL="${ITS_CONTROLLER_BUNDLE_URL:-https://itstelkom.web.app/artifacts/its-controller-files.tar.gz}"
CHECKSUM_URL="${ITS_CONTROLLER_BUNDLE_SHA_URL:-https://itstelkom.web.app/artifacts/its-controller-files.tar.gz.sha256}"
SERVICE_NAME="${ITS_CONTROLLER_SERVICE_NAME:-its-controller}"
SERVICE_USER="${ITS_CONTROLLER_SERVICE_USER:-raspberry5its}"
SERVICE_GROUP="${ITS_CONTROLLER_SERVICE_GROUP:-raspberry5its}"
REBOOT_AFTER_UPDATE="${ITS_CONTROLLER_REBOOT_AFTER_UPDATE:-true}"
DEVICE_ID="${ITS_DEVICE_ID:-raspberry-its}"
FIREBASE_BASE_URL="${ITS_FIREBASE_BASE_URL:-https://itstelkom-default-rtdb.asia-southeast1.firebasedatabase.app/devices}"
FIREBASE_AUTH="${ITS_FIREBASE_AUTH:-}"

json_escape() {
  if command -v python3 >/dev/null 2>&1; then
    python3 -c 'import json,sys; print(json.dumps(sys.argv[1])[1:-1])' "$1"
  else
    printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
  fi
}

auth_suffix() {
  if [ -n "$FIREBASE_AUTH" ]; then
    printf '?auth=%s' "$FIREBASE_AUTH"
  fi
}

publish_update_status() {
  local status="$1"
  local stage="$2"
  local message="$3"
  local now
  now="$(date +%s%3N)"
  local body
  body="$(cat <<JSON
{
  "status": "$(json_escape "$status")",
  "stage": "$(json_escape "$stage")",
  "message": "$(json_escape "$message")",
  "updatedAt": $now,
  "source": "raspberry-auto-update",
  "bundleSha": "$(json_escape "${REMOTE_SHA:-}")"
}
JSON
)"
  curl -fsS -X PUT \
    -H 'Content-Type: application/json' \
    -d "$body" \
    "${FIREBASE_BASE_URL%/}/${DEVICE_ID}/update.json$(auth_suffix)" >/dev/null 2>&1 || true
}

cleanup() {
  rm -f "$TMP_BUNDLE_FILE" "$TMP_SHA_FILE"
  rm -rf "$STAGING_DIR"
}

trap cleanup EXIT
trap 'publish_update_status "error" "failed" "Update controller gagal"; exit 1' ERR
exec 9>"$LOCK_FILE"
if command -v flock >/dev/null 2>&1; then
  flock -n 9 || {
    echo "Another controller update is already running."
    exit 0
  }
fi

publish_update_status "running" "checking" "Memeriksa checksum update controller"
curl -fL --retry 3 --retry-delay 2 --connect-timeout 10 "$CHECKSUM_URL" -o "$TMP_SHA_FILE"
REMOTE_SHA="$(tr -d '[:space:]' < "$TMP_SHA_FILE")"
if [ -z "$REMOTE_SHA" ]; then
  echo "Controller bundle checksum is empty."
  exit 1
fi

LOCAL_SHA=""
if [ -f "$LOCAL_BUNDLE_SHA_FILE" ]; then
  LOCAL_SHA="$(tr -d '[:space:]' < "$LOCAL_BUNDLE_SHA_FILE")"
fi

if [ "$LOCAL_SHA" = "$REMOTE_SHA" ] && [ -f "$LOCAL_BUNDLE_FILE" ] && [ -f "$JAR_FILE" ]; then
  publish_update_status "complete" "up-to-date" "Controller sudah versi terbaru"
  echo "Controller bundle already up to date."
  exit 0
fi

publish_update_status "running" "downloading" "Mengunduh paket update controller"
curl -fL --retry 3 --retry-delay 2 --connect-timeout 10 "$DOWNLOAD_URL" -o "$TMP_BUNDLE_FILE"
printf '%s  %s\n' "$REMOTE_SHA" "$TMP_BUNDLE_FILE" | sha256sum -c - >/dev/null
publish_update_status "running" "downloaded" "Paket update controller berhasil diunduh dan diverifikasi"

publish_update_status "running" "installing" "Menghentikan controller dan memasang file update"
if command -v systemctl >/dev/null 2>&1; then
  systemctl stop "$SERVICE_NAME" || true
fi

mkdir -p "$STAGING_DIR"
tar -xzf "$TMP_BUNDLE_FILE" -C "$STAGING_DIR"

if [ -f "$JAR_FILE" ]; then
  cp -f "$JAR_FILE" "$BACKUP_FILE"
fi

cp -a "$STAGING_DIR"/. "$TARGET_DIR"/
chmod 0644 "$TMP_BUNDLE_FILE"
cp -f "$TMP_BUNDLE_FILE" "$LOCAL_BUNDLE_FILE"
printf '%s\n' "$REMOTE_SHA" > "$LOCAL_BUNDLE_SHA_FILE"

chown -R "$SERVICE_USER:$SERVICE_GROUP" "$TARGET_DIR" || true
sync "$TARGET_DIR" || true

if [ -f "$TARGET_DIR/mediamtx.yml" ] && command -v systemctl >/dev/null 2>&1; then
  install -D -m 0644 "$TARGET_DIR/mediamtx.yml" /etc/mediamtx/mediamtx.yml || true
  systemctl restart mediamtx.service || true
fi

cleanup
trap - EXIT

if command -v systemctl >/dev/null 2>&1; then
  if [ "${REBOOT_AFTER_UPDATE,,}" = "true" ] || [ "${REBOOT_AFTER_UPDATE}" = "1" ]; then
    publish_update_status "complete" "rebooting" "Update controller selesai, Raspberry Pi restart"
    echo "Updated controller bundle. Rebooting Raspberry Pi so $SERVICE_NAME starts cleanly."
    systemctl reboot
    exit 0
  fi

  systemctl restart "$SERVICE_NAME"
  publish_update_status "complete" "restarted" "Update controller selesai dan service direstart"
fi

echo "Updated controller bundle and restarted $SERVICE_NAME"

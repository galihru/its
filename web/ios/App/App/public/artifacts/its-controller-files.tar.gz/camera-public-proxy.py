#!/usr/bin/env python3
import argparse
import http.client
import socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit


HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
}


class CameraProxyHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "ITS-CameraProxy/1.0"

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_cors_headers()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        self.forward()

    def do_HEAD(self):
        self.forward()

    def do_POST(self):
        self.forward()

    def do_PATCH(self):
        self.forward()

    def do_DELETE(self):
        self.forward()

    def log_message(self, fmt, *args):
        print("%s - - [%s] %s" % (self.address_string(), self.log_date_time_string(), fmt % args), flush=True)

    def upstream_port(self):
        parsed = urlsplit(self.path)
        path = parsed.path.rstrip("/")
        if path.startswith("/cam/whep") or path.startswith("/cam/whip"):
            return self.server.webrtc_port
        if self.command not in ("GET", "HEAD"):
            return self.server.webrtc_port
        return self.server.hls_port

    def forward(self):
        body = None
        length = self.headers.get("Content-Length")
        if length:
            body = self.rfile.read(int(length))

        port = self.upstream_port()
        headers = {
            key: value
            for key, value in self.headers.items()
            if key.lower() not in HOP_BY_HOP_HEADERS and key.lower() != "host"
        }
        headers["Host"] = f"127.0.0.1:{port}"

        conn = None
        try:
            conn = http.client.HTTPConnection("127.0.0.1", port, timeout=self.server.upstream_timeout)
            conn.request(self.command, self.path, body=body, headers=headers)
            resp = conn.getresponse()
            payload = b"" if self.command == "HEAD" else resp.read()

            self.send_response(resp.status, resp.reason)
            self.send_cors_headers()
            for key, value in resp.getheaders():
                lower = key.lower()
                if lower in HOP_BY_HOP_HEADERS:
                    continue
                if lower in ("access-control-allow-origin", "access-control-allow-methods", "access-control-allow-headers", "access-control-expose-headers"):
                    continue
                if lower == "content-length":
                    continue
                if lower == "location":
                    value = self.public_location(value)
                self.send_header(key, value)
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            if payload:
                self.wfile.write(payload)
        except (OSError, http.client.HTTPException, socket.timeout) as exc:
            message = f"camera proxy upstream error: {exc}".encode("utf-8")
            self.send_response(502)
            self.send_cors_headers()
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(message)))
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(message)
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

    def send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET,HEAD,POST,PATCH,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Expose-Headers", "Link,Location,Content-Type")

    def public_location(self, value):
        parsed = urlsplit(value)
        if not parsed.scheme or not parsed.netloc:
            return value
        if parsed.hostname not in ("127.0.0.1", "localhost"):
            return value
        if parsed.port not in (self.server.webrtc_port, self.server.hls_port):
            return value
        host = self.headers.get("Host", "")
        if not host:
            return value
        scheme = self.headers.get("X-Forwarded-Proto")
        if not scheme:
            scheme = "http" if host.startswith("127.") or host.startswith("localhost") else "https"
        path = parsed.path or "/"
        if parsed.query:
            path = f"{path}?{parsed.query}"
        return f"{scheme}://{host}{path}"


def main():
    parser = argparse.ArgumentParser(description="Proxy MediaMTX WebRTC and HLS on one public port")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8890)
    parser.add_argument("--webrtc-port", type=int, default=8889)
    parser.add_argument("--hls-port", type=int, default=8888)
    parser.add_argument("--timeout", type=float, default=30.0)
    args = parser.parse_args()

    server = ThreadingHTTPServer((args.host, args.port), CameraProxyHandler)
    server.webrtc_port = args.webrtc_port
    server.hls_port = args.hls_port
    server.upstream_timeout = args.timeout
    print(
        f"ITS camera proxy listening on {args.host}:{args.port} "
        f"(WHEP->{args.webrtc_port}, HLS->{args.hls_port})",
        flush=True,
    )
    server.serve_forever()


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
# DEVICE: /dev/video0 or the literal word 'auto' to detect first /dev/video* device
DEVICE="${1:-/dev/video0}"
PORT="${2:-8080}"
WIDTH="${3:-640}"
HEIGHT="${4:-480}"
FPS="${5:-10}"
QUALITY="${6:-5}"
# Optional PATH (7th arg) - if provided, stream will be served at /<PATH>/?listen=1
# Example: pass 'cam' so the tunnel URL https://host/cam/ will be forwarded correctly.
STREAM_PATH_ARG="${7:-}"

if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "ffmpeg tidak ditemukan. Install ffmpeg di Raspberry Pi dahulu."
  exit 1
fi

if [ "$DEVICE" = "auto" ]; then
  # pick first existing /dev/video* device
  for dev in /dev/video*; do
    if [ -e "$dev" ]; then
      DEVICE="$dev"
      break
    fi
  done
fi

if [ -z "$STREAM_PATH_ARG" ]; then
  STREAM_PATH="stream.mjpg"
else
  # normalize: strip leading/trailing slashes
  STREAM_PATH="${STREAM_PATH_ARG#/}"
  STREAM_PATH="${STREAM_PATH%/}"
fi

# Determine host IP (prefer non-loopback). Fall back to 0.0.0.0 if none.
HOST_IP="$(hostname -I 2>/dev/null | awk '{print $1}' || true)"
if [ -z "$HOST_IP" ] || [ "$HOST_IP" = "127.0.0.1" ]; then
  # try ip command as fallback
  HOST_IP="$(ip -4 addr show scope global 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -n1 || true)"
fi
if [ -z "$HOST_IP" ]; then
  HOST_IP="0.0.0.0"
fi

echo "Menjalankan kamera dari $DEVICE pada http://$HOST_IP:$PORT/${STREAM_PATH}"

echo "Gunakan browser atau aplikasi web untuk membuka http://<raspi-ip>:$PORT/${STREAM_PATH} atau gunakan tunnel public yang menunjuk ke path tersebut."

if [ "$HOST_IP" = "0.0.0.0" ]; then
  echo "Warning: tidak menemukan alamat host non-loopback — akan bind ke 0.0.0.0" >&2
fi

exec ffmpeg -f v4l2 -framerate "$FPS" -video_size "${WIDTH}x${HEIGHT}" -i "$DEVICE" \
  -c:v libx264 -preset veryfast -tune zerolatency -pix_fmt yuv420p -f mjpeg "http://$HOST_IP:${PORT}/${STREAM_PATH}?listen=1"
